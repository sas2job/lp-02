<?php

/**
* user core class
*/
class core extends user_cms_core_edition {
	
	# здесь код для изменения ядра системы
}